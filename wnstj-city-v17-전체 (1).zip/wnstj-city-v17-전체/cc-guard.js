/* ============================================================================
 * cc-guard.js — 개발자 도구(콘솔) 차단 레이어
 * 게임 본체(index.html)보다 먼저 로드됩니다.
 * 목적: 일반 유저가 F12/콘솔로 money 값을 바꾸는 것을 막는 "1차 방어"
 * 주의: 콘솔 차단은 완벽한 보안이 아닙니다(파일 수정·직접 API 호출은 못 막음).
 *       진짜 방어는 서버(DB) 쪽 검증입니다. 이 파일은 UX 단속용입니다.
 * ==========================================================================*/
(function () {
  'use strict';

  // 이미 한 번 실행됐으면 중복 실행 방지
  if (window.__ccGuard) return;
  window.__ccGuard = 1;

  // --------------------------------------------------------------
  // 0) 비상 스위치
  //    콘솔 없이도 막히는 상황을 대비해, URL 뒤에 ?noconsole=1 을 붙이면
  //    차단이 완전히 해제됩니다. (개발/테스트용)
  // --------------------------------------------------------------
  if (/[?&]noconsole=1/.test(location.search)) { window.__ccGuardOff = 1; return; }

  // --------------------------------------------------------------
  // 1) 콘솔 함수 무력화 + 값 노출 방지
  // --------------------------------------------------------------
  var noop = function () {};
  var methods = ['log','info','warn','error','debug','trace','dir','dirxml','table',
                 'group','groupCollapsed','groupEnd','time','timeEnd','count','countReset',
                 'assert','clear','profile','profileEnd','timeStamp'];
  methods.forEach(function (k) {
    try { if (console && console[k]) console[k] = noop; } catch (e) {}
  });

  // --------------------------------------------------------------
  // 2) 개발자 도구 열림 감지
  //    - debugger 트릭: 도구가 열려 있으면 멈춘 시간이 길어짐
  //    - 창 크기 차이 감지(도킹형 도구)
  // --------------------------------------------------------------
  var devOpen = false;
  var THRESHOLD = 120; // ms

  setInterval(function () {
    var t0 = performance.now();
    // eslint-disable-next-line no-debugger
    debugger;
    if (performance.now() - t0 > THRESHOLD) devOpen = true;
  }, 700);

  // 도킹된 도구는 뷰포트가 줄어드는 특성이 있음 (오탐이 적도록 폭 기준)
  var baseW = window.outerWidth || 0, baseH = window.outerHeight || 0;
  setInterval(function () {
    var dw = Math.abs((window.outerWidth || 0) - (window.innerWidth || 0));
    var dh = Math.abs((window.outerHeight || 0) - (window.innerHeight || 0));
    if (dw > 220 || dh > 320) devOpen = true;
  }, 1200);

  // --------------------------------------------------------------
  // 3) 감지되면 경고 후 리로드 (게임 상태를 날려서 조작 무효화)
  // --------------------------------------------------------------
  var warned = false;
  setInterval(function () {
    if (!devOpen) return;
    devOpen = false;
    if (!warned) {
      warned = true;
      try { alert('개발자 도구는 사용할 수 없습니다.\n게임을 새로고침합니다.'); } catch (e) {}
    }
    try { location.reload(); } catch (e) {}
  }, 1000);

  // --------------------------------------------------------------
  // 4) 단축키 / 우클릭 차단
  // --------------------------------------------------------------
  document.addEventListener('contextmenu', function (e) {
    // 텍스트 입력창(채팅)에서는 허용
    var t = e.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
    e.preventDefault();
  }, true);

  document.addEventListener('keydown', function (e) {
    var k = (e.key || '').toUpperCase();
    var block =
      e.key === 'F12' ||
      (e.ctrlKey && e.shiftKey && (k === 'I' || k === 'J' || k === 'C' || k === 'K')) ||
      (e.metaKey && e.altKey && (k === 'I' || k === 'J' || k === 'C')) ||  // macOS
      (e.ctrlKey && k === 'U') ||
      (e.metaKey && e.altKey && k === 'U');
    if (block) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  // --------------------------------------------------------------
  // 5) window 전역 변수 직접 대입 감시 (money, own 등)
  //    콘솔에서 money = 99999 하면 여기서 잡아서 리로드.
  //    게임 내부 변수는 클로저 안에 있어서 여기 안 잡히지만,
  //    "전역으로 만든" 경우와 디버거로 끌어올린 경우를 커버.
  // --------------------------------------------------------------
  ['money', 'own', 'myName'].forEach(function (name) {
    try {
      var v;
      Object.defineProperty(window, name, {
        configurable: true,
        get: function () { return v; },
        set: function (nv) {
          // 게임이 스스로 쓰는 게 아니라 콘솔/외부에서 쓰는 경우 → 조작 시도
          if (window.__ccInternal) { v = nv; return; }
          try { location.reload(); } catch (e) {}
        }
      });
    } catch (e) {}
  });

  // --------------------------------------------------------------
  // 6) iframe 삽입(자체 콘솔 UI로 우회) 방지 - 최상위 창에서만 동작
  // --------------------------------------------------------------
  try {
    if (window.top !== window.self) {
      // 프레임 안에서 실행 중이면 부모로 나가라고 요청
      window.top.location = window.self.location.href;
    }
  } catch (e) {}
})();
