-- ============================================================================
-- CRIME CITY 3D · 관리자 패널용 스키마 (Supabase SQL Editor에서 한 번만 실행)
-- ============================================================================
-- 관리자 패널이 유저의 돈/무기/강화를 "즉시" 바꾸기 위해 쓰는 컬럼 2개를 추가합니다.
--   adm      : 관리자가 적용한 최신 값 { money, own }  → 게임이 읽어서 덮어씀
--   adm_seq  : 수정 횟수. 게임은 이 숫자가 올라갔는지만 확인합니다.
-- ============================================================================

alter table public.cc_profiles add column if not exists adm     jsonb;
alter table public.cc_profiles add column if not exists adm_seq integer not null default 0;

-- 관리자 패널 목록이 빨라지도록 이름 인덱스 (이미 있으면 무시)
create index if not exists cc_profiles_name_idx on public.cc_profiles (name);

-- 확인
select name, money, adm_seq, adm is not null as has_admin_payload
from public.cc_profiles
order by updated_at desc
limit 10;
